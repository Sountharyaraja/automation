import static org.junit.Assert.*;

import org.junit.*;


public class ShippmentJUnit {

	ShipmentBO shipmentBO;
	@Before
	public void objectCeration()
	{
		shipmentBO = new ShipmentBO();
	}
	
	@Test
	public void testShippedItemCount()
	{
		int a = shipmentBO.findShippedItemCount(10, 100, 2000);
		assertEquals(a, 10);
		
		int b = shipmentBO.findShippedItemCount(10, 100, 500);
		assertEquals(b, 5);
	}
	
	@Test
	public void testLeftOutCount()
	{
		int a = shipmentBO.findLeftOutCount(10, 5);
		assertEquals(a, 5);
	}
	
	
}
