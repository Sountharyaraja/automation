import java.util.StringTokenizer;
public class GrammerCheckBO {
	public String checkGrammer(String sentence) {
		String nextToken = null;
		String currentToken;
		StringTokenizer tokenize = new StringTokenizer(sentence);
		StringBuilder correctedSentence = new StringBuilder();
		while(tokenize.hasMoreTokens()){
		   currentToken = tokenize.nextToken();
		   if(tokenize.hasMoreTokens())
			   nextToken = tokenize.nextToken();
		   if(currentToken.equals("a") && ((nextToken.charAt(0) == 'a' || nextToken.charAt(0) == 'A') || (nextToken.charAt(0) == 'e' || nextToken.charAt(0) == 'E') || (nextToken.charAt(0) == 'i' || nextToken.charAt(0) == 'I') || (nextToken.charAt(0) == 'o' || nextToken.charAt(0) == 'O') || (nextToken.charAt(0) == 'u' || nextToken.charAt(0) == 'U'))){
			   correctedSentence.append(currentToken.replaceAll("a", "an") + " " + nextToken + " ");
		   }
		   else{
			   if(nextToken != null)
				   correctedSentence.append(currentToken + " " + nextToken + " ");
			   else
				   correctedSentence.append(currentToken + " ");
		   }
		   nextToken = null;
		}
		return correctedSentence.toString().trim();
	}
}