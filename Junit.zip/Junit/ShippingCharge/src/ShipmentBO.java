public class ShipmentBO {
	public double evaluateShippingCharge(double wt, double dt, String mo) {
		double charge = 0.0;
		if (mo.equalsIgnoreCase("Road")) {
			charge = (wt * 0.02) + (dt * 0.04);
		} else if (mo.equalsIgnoreCase("Sea")) {
			charge = (wt * 0.02) + (dt * 0.06);
			charge = charge * 1.02;
		} else if (mo.equalsIgnoreCase("Air")) {
			charge = (wt * 0.02) + (dt * 0.1);
			charge = charge + 300;
		}
		return charge;
	}
}